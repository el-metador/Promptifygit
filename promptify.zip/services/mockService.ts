import { Prompt, User, Ad, Review } from '../types';

const STORAGE_KEYS = {
  USER: 'promptify_user_prod_v2',
  PROMPTS: 'promptify_prompts_prod_v2',
};

// Initial Data
const INITIAL_PROMPTS: Prompt[] = [
  {
    id: '101',
    title: 'Ethereal Portraits',
    description: 'Create hauntingly beautiful portraits with soft, volumetric lighting and dreamlike compositions.',
    promptText: 'Portrait photography, 85mm lens, f/1.8, soft volumetric fog, bioluminescent accents, ethereal glow, cinematic color grading, high detail skin texture --v 6.0',
    aiModel: 'Sora 2',
    author: 'Lumina',
    isTrending: true,
    ratingAvg: 4.9,
    imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=1964&auto=format&fit=crop',
    unlockCount: 3420,
    reviews: []
  },
  {
    id: '102',
    title: 'Neon Tokyo Drift',
    description: 'Cyberpunk street racing aesthetic with wet asphalt reflections and dynamic motion blur.',
    promptText: 'Night city street race, cyberpunk tokyo, wet asphalt, neon reflections, motion blur, rain droplets on camera lens, 8k resolution, photorealistic.',
    aiModel: 'Veo 3.1',
    author: 'SpeedDemon',
    isTrending: true,
    ratingAvg: 4.8,
    imageUrl: 'https://images.unsplash.com/photo-1552089123-26523945132d?q=80&w=2070&auto=format&fit=crop',
    unlockCount: 2150,
    reviews: []
  },
  {
    id: '103',
    title: 'Minimalist UX Mockups',
    description: 'Generate clean, isometric 3D device mockups for app presentations.',
    promptText: 'Isometric 3D render, matte clay material, iphone 15 pro mockup, floating elements, soft pastel background, studio lighting, minimal shadows.',
    aiModel: 'Nano Banana Pro',
    author: 'DesignSystem',
    isTrending: false,
    ratingAvg: 4.5,
    imageUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=1974&auto=format&fit=crop',
    unlockCount: 890,
    reviews: []
  },
  {
    id: '104',
    title: 'Abstract Fluid Motion',
    description: 'Liquid simulation prompts for backgrounds and dynamic wallpapers.',
    promptText: 'Macro shot of mixing paint, oil and water, swirling galaxy patterns, vibrant colors, 4k 60fps, slow motion, fluid dynamics.',
    aiModel: 'Gemini 3 Pro',
    author: 'FlowState',
    isTrending: true,
    ratingAvg: 4.7,
    imageUrl: 'https://images.unsplash.com/photo-1541701494587-cb58502866ab?q=80&w=2070&auto=format&fit=crop',
    unlockCount: 1200,
    reviews: []
  }
];

const MOCK_ADS: Ad[] = [
  {
    id: 'ad1',
    title: 'Unlock Pro Access',
    description: 'Get 500 coins and exclusive models.',
    imageUrl: 'https://images.unsplash.com/photo-1633265486064-086b219458ec?q=80&w=2070&auto=format&fit=crop',
    cta: 'View Plan'
  }
];

// Helper to get persistence
const getStoredPrompts = (): Prompt[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEYS.PROMPTS);
    if (stored) return JSON.parse(stored);
  } catch (e) {
    console.error("Error reading storage", e);
  }
  localStorage.setItem(STORAGE_KEYS.PROMPTS, JSON.stringify(INITIAL_PROMPTS));
  return INITIAL_PROMPTS;
};

const savePrompts = (prompts: Prompt[]) => {
  localStorage.setItem(STORAGE_KEYS.PROMPTS, JSON.stringify(prompts));
};

export const mockService = {
  login: async (email: string, password?: string): Promise<User> => {
    await new Promise(resolve => setTimeout(resolve, 800));
    
    let user: User;

    // Admin Login Check
    if (email === 'jesqman@admin.com' && password === 'jesqman') {
      user = {
        id: 'admin_1',
        email,
        name: 'Jesqman',
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150',
        coins: 9999,
        role: 'admin',
        unlockedPromptIds: []
      };
    } else {
      // Mock User
      const existingUsers = localStorage.getItem('promptify_users_db');
      const usersDb = existingUsers ? JSON.parse(existingUsers) : {};
      
      if (usersDb[email]) {
        user = usersDb[email];
      } else {
        user = {
            id: `user_${Date.now()}`,
            email,
            name: email.split('@')[0],
            avatar: `https://ui-avatars.com/api/?name=${email.split('@')[0]}&background=D9FF00&color=000`,
            coins: 10,
            role: 'user',
            unlockedPromptIds: []
        };
        usersDb[email] = user;
        localStorage.setItem('promptify_users_db', JSON.stringify(usersDb));
      }
    }
    
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
    return user;
  },

  getCurrentUser: async (): Promise<User | null> => {
     const stored = localStorage.getItem(STORAGE_KEYS.USER);
     return stored ? JSON.parse(stored) : null;
  },

  logout: async () => {
    localStorage.removeItem(STORAGE_KEYS.USER);
  },

  getPrompts: async (): Promise<Prompt[]> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    return getStoredPrompts();
  },

  createPrompt: async (prompt: Omit<Prompt, 'id' | 'ratingAvg' | 'unlockCount' | 'reviews'>): Promise<Prompt> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const prompts = getStoredPrompts();
    const newPrompt: Prompt = {
      ...prompt,
      id: Date.now().toString(), // Simple ID gen
      ratingAvg: 0,
      unlockCount: 0,
      reviews: []
    };
    // Add to top
    const updatedPrompts = [newPrompt, ...prompts];
    savePrompts(updatedPrompts);
    return newPrompt;
  },

  toggleTrending: async (promptId: string): Promise<void> => {
    const prompts = getStoredPrompts();
    const updated = prompts.map(p => p.id === promptId ? { ...p, isTrending: !p.isTrending } : p);
    savePrompts(updated);
  },

  deletePrompt: async (promptId: string): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 300));
    const prompts = getStoredPrompts();
    // Logic Fix: Filter out the ID
    const updated = prompts.filter(p => p.id !== promptId);
    // Logic Fix: Save the filtered array
    savePrompts(updated);
  },

  unlockPrompt: async (userId: string, promptId: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 600));
    
    const userString = localStorage.getItem(STORAGE_KEYS.USER);
    if (!userString) return false;
    
    const user = JSON.parse(userString);
    if (user.coins < 1) return false;
    
    // Update User
    user.coins -= 1;
    if (!user.unlockedPromptIds.includes(promptId)) {
      user.unlockedPromptIds.push(promptId);
    }
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));

    // Update Prompt Stats
    const prompts = getStoredPrompts();
    const updatedPrompts = prompts.map(p => {
        if(p.id === promptId) {
            return { ...p, unlockCount: p.unlockCount + 1 };
        }
        return p;
    });
    savePrompts(updatedPrompts);

    return true;
  },

  getRandomAd: (): Ad => {
    return MOCK_ADS[Math.floor(Math.random() * MOCK_ADS.length)];
  },
  
  submitReview: async (promptId: string, review: Review): Promise<void> => {
    await new Promise(resolve => setTimeout(resolve, 500));
    const prompts = getStoredPrompts();
    
    const updatedPrompts = prompts.map(p => {
        if (p.id === promptId) {
            const alreadyReviewed = p.reviews.some(r => r.userId === review.userId);
            if (alreadyReviewed) {
                throw new Error("You have already reviewed this prompt.");
            }

            const newReviews = [review, ...p.reviews];
            const sum = newReviews.reduce((acc, r) => acc + r.rating, 0);
            const avg = Number((sum / newReviews.length).toFixed(1));
            return { ...p, reviews: newReviews, ratingAvg: avg };
        }
        return p;
    });
    savePrompts(updatedPrompts);
  }
};
