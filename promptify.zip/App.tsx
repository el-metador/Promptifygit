import React, { useState, useEffect } from 'react';
import { Sparkles, Search, Coins, LogOut, LayoutGrid, Filter, User as UserIcon } from 'lucide-react';
import { Prompt, User, FilterState } from './types';
import { mockService } from './services/mockService';
import { Button } from './components/Button';
import { PromptCard } from './components/PromptCard';
import { PromptModal } from './components/PromptModal';
import { LoginModal } from './components/LoginModal';
import { AdminDashboard } from './components/AdminDashboard';
import { SplashScreen } from './components/SplashScreen';
import { BottomNav } from './components/BottomNav';
import { ProfilePage } from './components/ProfilePage';
import { NotFound } from './components/NotFound';
import { AdBanner } from './components/AdBanner';

const App: React.FC = () => {
  // Routing State
  const [currentTab, setCurrentTab] = useState('home'); // home, library, profile, admin, create_placeholder, 404
  const [showSplash, setShowSplash] = useState(true);

  // Global State
  const [user, setUser] = useState<User | null>(null);
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);

  // UI State
  const [activePrompt, setActivePrompt] = useState<Prompt | null>(null);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [filters, setFilters] = useState<FilterState>({
    model: 'All',
    onlyTrending: false,
    search: '',
    sort: 'rating'
  });

  // Init Data
  const refreshData = async () => {
      const data = await mockService.getPrompts();
      setPrompts(data);
      const currentUser = await mockService.getCurrentUser();
      setUser(currentUser);
      setLoading(false);
  };

  useEffect(() => {
    // Artificial splash screen delay
    const timer = setTimeout(() => {
        setShowSplash(false);
    }, 2000);
    
    refreshData();
    return () => clearTimeout(timer);
  }, []);

  // Handlers
  const handleLogin = async (email: string, password?: string) => {
    const userData = await mockService.login(email, password);
    setUser(userData);
    if (userData.role === 'admin') {
        setCurrentTab('admin');
    }
  };

  const handleLogout = async () => {
    await mockService.logout();
    setUser(null);
    setCurrentTab('home');
  };

  const handleUnlockPrompt = async (promptId: string) => {
    if (!user) return;
    const success = await mockService.unlockPrompt(user.id, promptId);
    if (success) {
         const updatedUser = await mockService.getCurrentUser();
         setUser(updatedUser);
         setPrompts(prev => prev.map(p => 
            p.id === promptId ? { ...p, unlockCount: p.unlockCount + 1 } : p
         ));
    }
  };

  // Filter Logic
  const filteredPrompts = prompts.filter(p => {
    const matchesSearch = p.title.toLowerCase().includes(filters.search.toLowerCase()) || 
                          p.description.toLowerCase().includes(filters.search.toLowerCase());
    const matchesModel = filters.model === 'All' || p.aiModel === filters.model;
    const matchesTrend = filters.onlyTrending ? p.isTrending : true;
    return matchesSearch && matchesModel && matchesTrend;
  }).sort((a, b) => {
      // Prioritize Trending
      if (a.isTrending && !b.isTrending) return -1;
      if (!a.isTrending && b.isTrending) return 1;
      return b.ratingAvg - a.ratingAvg;
  });

  // Library Data
  const libraryPrompts = prompts.filter(p => user?.unlockedPromptIds.includes(p.id));

  if (showSplash || loading) {
      return <SplashScreen />;
  }

  // Admin View
  if (currentTab === 'admin') {
      return (
          <AdminDashboard 
            prompts={prompts} 
            onRefresh={refreshData}
            onLogout={handleLogout}
            onBack={() => setCurrentTab('home')}
          />
      );
  }

  // Profile View
  if (currentTab === 'profile') {
      if (!user) {
          // Redirect to login if accessing profile without auth
          setIsLoginOpen(true);
          setCurrentTab('home');
          return null; 
      }
      return (
          <>
            <ProfilePage 
                user={user} 
                unlockedPrompts={libraryPrompts} 
                onLogout={handleLogout}
                onPromptClick={setActivePrompt}
            />
            <BottomNav currentTab={currentTab} onTabChange={setCurrentTab} userRole={user.role} />
             {activePrompt && (
                <PromptModal 
                    prompt={activePrompt}
                    user={user}
                    isUnlocked={true}
                    onClose={() => setActivePrompt(null)}
                    onUnlock={handleUnlockPrompt}
                />
            )}
          </>
      );
  }

  // Library View
  if (currentTab === 'library') {
      if (!user) {
          setIsLoginOpen(true);
          setCurrentTab('home');
          return null;
      }
  }

  // Create Placeholder (Modal simulation)
  if (currentTab === 'create_placeholder') {
      // In real app, this would open a camera/editor
      alert('Mobile creation studio coming in v2!');
      setCurrentTab('home');
      return null;
  }

  return (
    <div className="min-h-screen pb-24 bg-black text-white">
      
      {/* --- HEADER (Only show on Home/Library) --- */}
      <header className="sticky top-0 z-40 w-full bg-black/80 backdrop-blur-xl border-b border-zinc-900">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2" onClick={() => setCurrentTab('home')}>
            <Sparkles className="h-6 w-6 text-primary fill-current" />
            <span className="text-xl font-black tracking-tighter text-white">Promptify</span>
          </div>

          <div className="flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 rounded-full bg-zinc-900 px-3 py-1.5 border border-zinc-800">
                  <Coins className="h-4 w-4 text-primary fill-current" />
                  <span className="font-bold text-sm text-white">{user.coins}</span>
                </div>
                <img 
                    src={user.avatar} 
                    alt={user.name} 
                    className="h-8 w-8 rounded-full border border-zinc-800 object-cover cursor-pointer" 
                    onClick={() => setCurrentTab('profile')}
                />
              </div>
            ) : (
              <Button onClick={() => setIsLoginOpen(true)} size="sm" variant="neon">
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* --- MAIN CONTENT --- */}
      <main className="container mx-auto px-4 py-6 animate-fade-in">
        
        {/* Title for sections */}
        <h2 className="text-2xl font-black mb-6 uppercase tracking-tight">
            {currentTab === 'library' ? 'Your Collection' : 'Explore Ideas'}
        </h2>

        {/* Filters & Search (Only Home) */}
        {currentTab === 'home' && (
            <div className="mb-6 space-y-4">
                <div className="relative">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
                    <input 
                        type="text" 
                        placeholder="Search for effects, transitions..." 
                        className="w-full rounded-full border border-zinc-800 bg-zinc-900 py-3 pl-10 pr-4 text-sm text-white focus:border-primary focus:outline-none placeholder:text-zinc-600"
                        value={filters.search}
                        onChange={(e) => setFilters(prev => ({...prev, search: e.target.value}))}
                    />
                </div>
                
                <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar">
                    <button 
                        onClick={() => setFilters(prev => ({...prev, onlyTrending: !prev.onlyTrending}))}
                        className={`flex items-center gap-1.5 rounded-full border px-4 py-2 text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all ${filters.onlyTrending ? 'bg-primary text-black border-primary' : 'border-zinc-800 bg-zinc-900 text-zinc-400'}`}
                    >
                        <LayoutGrid className="h-3 w-3" />
                        Trending
                    </button>
                    {['All', 'Nano Banana Pro', 'Veo 3.1', 'Sora 2', 'Gemini 3 Pro'].map(m => (
                        <button
                            key={m}
                            onClick={() => setFilters(prev => ({...prev, model: m}))}
                            className={`rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all border ${filters.model === m ? 'bg-white text-black border-white' : 'border-zinc-800 bg-zinc-900 text-zinc-400'}`}
                        >
                            {m}
                        </button>
                    ))}
                </div>
            </div>
        )}

        {/* PROMO BANNER IN FEED */}
        {currentTab === 'home' && !filters.search && (
            <AdBanner ad={mockService.getRandomAd()} />
        )}

        {/* Results Grid - Vertical Masonry Style */}
        {/* We use a simple grid here, but styled like the reference */}
        {currentTab === 'home' ? (
             filteredPrompts.length > 0 ? (
                 <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                    {filteredPrompts.map(prompt => (
                        <PromptCard 
                            key={prompt.id} 
                            prompt={prompt} 
                            isUnlocked={user?.unlockedPromptIds.includes(prompt.id) || false}
                            onClick={() => setActivePrompt(prompt)}
                        />
                    ))}
                </div>
            ) : (
               <div className="py-20">
                   <NotFound onHome={() => setFilters({model: 'All', onlyTrending: false, search: '', sort: 'rating'})} />
               </div>
            )
        ) : (
            // Library View
            libraryPrompts.length > 0 ? (
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                    {libraryPrompts.map(prompt => (
                        <PromptCard 
                            key={prompt.id} 
                            prompt={prompt} 
                            isUnlocked={true}
                            onClick={() => setActivePrompt(prompt)}
                        />
                    ))}
                </div>
            ) : (
                <div className="flex flex-col items-center justify-center py-20 text-center text-zinc-500">
                    <p className="mb-4">You haven't unlocked any prompts yet.</p>
                    <Button onClick={() => setCurrentTab('home')} variant="neon" size="sm">Browse Feed</Button>
                </div>
            )
        )}
       
      </main>

      {/* --- MODALS --- */}
      {activePrompt && (
        <PromptModal 
            prompt={activePrompt}
            user={user}
            isUnlocked={user?.unlockedPromptIds.includes(activePrompt.id) || false}
            onClose={() => setActivePrompt(null)}
            onUnlock={handleUnlockPrompt}
        />
      )}

      {isLoginOpen && (
        <LoginModal 
            onClose={() => setIsLoginOpen(false)}
            onLogin={handleLogin}
        />
      )}

      {/* --- BOTTOM NAV --- */}
      <BottomNav 
        currentTab={currentTab} 
        onTabChange={setCurrentTab} 
        userRole={user?.role}
      />

    </div>
  );
};

export default App;