import React, { useState } from 'react';
import { Prompt } from '../types';
import { Button } from './Button';
import { Trash2, Zap, Plus, Search, LogOut, ArrowLeft, Image as ImageIcon, CheckCircle, Loader2 } from 'lucide-react';
import { mockService } from '../services/mockService';

interface AdminDashboardProps {
  prompts: Prompt[];
  onRefresh: () => void;
  onLogout: () => void;
  onBack: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ prompts, onRefresh, onLogout, onBack }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [loadingAction, setLoadingAction] = useState<string | null>(null);
  
  // New Prompt State
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [newPromptText, setNewPromptText] = useState('');
  const [newModel, setNewModel] = useState<Prompt['aiModel']>('Nano Banana Pro');
  const [newImage, setNewImage] = useState('https://images.unsplash.com/photo-1614728263952-84ea256f9679?q=80&w=2608&auto=format&fit=crop');

  const handleToggleTrending = async (id: string) => {
    setLoadingAction(id);
    await mockService.toggleTrending(id);
    await onRefresh();
    setLoadingAction(null);
  };

  const handleDelete = async (id: string) => {
    if(confirm('Delete this prompt permanently?')) {
        setLoadingAction(id);
        // await to ensure storage is updated before refresh
        await mockService.deletePrompt(id);
        // Trigger parent refresh to fetch new list from storage
        await onRefresh();
        setLoadingAction(null);
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoadingAction('create');
    await mockService.createPrompt({
        title: newTitle,
        description: newDesc,
        promptText: newPromptText,
        aiModel: newModel,
        author: 'Admin',
        isTrending: false,
        imageUrl: newImage
    });
    setLoadingAction(null);
    setIsCreating(false);
    
    // Reset form
    setNewTitle('');
    setNewDesc('');
    setNewPromptText('');
    
    await onRefresh();
  };

  const filtered = prompts.filter(p => p.title.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="min-h-screen bg-black text-white p-4 pb-32 animate-fade-in">
      <div className="max-w-5xl mx-auto">
        
        {/* Header */}
        <div className="sticky top-0 z-30 bg-black/80 backdrop-blur-xl -mx-4 px-4 py-4 mb-6 border-b border-white/5">
            <div className="flex items-center justify-between mb-4">
                <Button variant="ghost" size="sm" onClick={onBack} className="pl-0 text-zinc-400 hover:text-white">
                    <ArrowLeft className="w-4 h-4 mr-2" /> Back to App
                </Button>
                <Button variant="ghost" size="sm" onClick={onLogout} className="text-red-400 hover:text-red-300">
                    <LogOut className="w-4 h-4 mr-2" /> Logout
                </Button>
            </div>
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-bold text-white tracking-tight">Studio Dashboard</h1>
                    <p className="text-xs text-zinc-500 mt-1">Manage content database</p>
                </div>
                <Button onClick={() => setIsCreating(true)} variant="primary" size="md">
                    <Plus className="w-4 h-4 mr-2" /> Create Prompt
                </Button>
            </div>
        </div>

        {/* Search */}
        <div className="mb-6 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-zinc-500" />
            <input 
                type="text" 
                placeholder="Search prompts by title..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-surface-highlight border border-white/5 rounded-xl py-3 pl-10 pr-4 focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/50 text-sm placeholder:text-zinc-600 transition-all"
            />
        </div>

        {/* List */}
        <div className="grid gap-3">
            {filtered.length === 0 ? (
                <div className="text-center py-12 border border-dashed border-white/10 rounded-2xl">
                    <p className="text-zinc-500 text-sm">No prompts found.</p>
                </div>
            ) : (
                filtered.map(prompt => (
                    <div key={prompt.id} className="group bg-surface-highlight border border-white/5 rounded-xl p-3 flex items-center gap-4 transition-colors hover:border-white/10">
                        {/* Image */}
                        <div className="relative w-16 h-20 flex-shrink-0">
                            <img src={prompt.imageUrl} alt="" className="w-full h-full object-cover rounded-lg bg-zinc-800" />
                            {prompt.isTrending && (
                                <div className="absolute top-1 left-1 bg-primary text-black rounded px-1 py-0.5">
                                    <Zap className="w-2 h-2 fill-current" />
                                </div>
                            )}
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                            <h3 className="font-semibold text-white truncate text-sm mb-1">{prompt.title}</h3>
                            <div className="flex items-center gap-2 mb-2">
                                <span className="text-[10px] bg-white/5 px-2 py-0.5 rounded text-zinc-400 border border-white/5">
                                    {prompt.aiModel}
                                </span>
                            </div>
                            <div className="flex items-center gap-3 text-[10px] text-zinc-500">
                                <span>{prompt.unlockCount} unlocks</span>
                                <span>★ {prompt.ratingAvg}</span>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="flex flex-col gap-2">
                            <button 
                                onClick={() => handleToggleTrending(prompt.id)}
                                disabled={loadingAction === prompt.id}
                                className={`p-2 rounded-lg transition-all ${prompt.isTrending ? 'bg-primary/20 text-primary' : 'bg-black text-zinc-500 hover:text-white border border-white/10'}`}
                            >
                                {loadingAction === prompt.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className={`w-4 h-4 ${prompt.isTrending ? 'fill-current' : ''}`} />}
                            </button>
                            <button 
                                onClick={() => handleDelete(prompt.id)}
                                disabled={loadingAction === prompt.id}
                                className="p-2 rounded-lg bg-black text-zinc-500 hover:text-red-500 hover:bg-red-500/10 border border-white/10 transition-colors"
                            >
                                {loadingAction === prompt.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                            </button>
                        </div>
                    </div>
                ))
            )}
        </div>

      </div>

      {/* Create Modal */}
      {isCreating && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
              <div className="bg-surface border border-white/10 rounded-2xl w-full max-w-lg shadow-2xl overflow-y-auto max-h-[90vh] flex flex-col">
                  <div className="p-6 border-b border-white/5">
                      <h2 className="text-lg font-bold text-white">New Prompt</h2>
                  </div>
                  
                  <div className="p-6 space-y-5 overflow-y-auto">
                      <form id="create-form" onSubmit={handleCreate} className="space-y-5">
                          <div>
                              <label className="block text-[10px] font-bold uppercase text-zinc-500 mb-1.5">Title</label>
                              <input required className="w-full bg-black border border-white/10 rounded-lg p-3 text-white focus:border-primary outline-none transition-colors text-sm" placeholder="e.g. Cinematic Neon" value={newTitle} onChange={e => setNewTitle(e.target.value)} />
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                              <div>
                                <label className="block text-[10px] font-bold uppercase text-zinc-500 mb-1.5">Model</label>
                                <select className="w-full bg-black border border-white/10 rounded-lg p-3 text-sm text-white focus:border-primary outline-none" value={newModel} onChange={e => setNewModel(e.target.value as any)}>
                                    <option>Nano Banana Pro</option>
                                    <option>Veo 3.1</option>
                                    <option>Sora 2</option>
                                    <option>Gemini 3 Pro</option>
                                </select>
                              </div>
                          </div>

                          <div>
                            <label className="block text-[10px] font-bold uppercase text-zinc-500 mb-1.5">Cover Image URL</label>
                            <div className="relative">
                                <ImageIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                                <input 
                                    className="w-full bg-black border border-white/10 rounded-lg py-3 pl-10 pr-3 text-sm text-white focus:border-primary outline-none" 
                                    placeholder="https://..." 
                                    value={newImage} 
                                    onChange={e => setNewImage(e.target.value)} 
                                />
                            </div>
                            {newImage && (
                                <div className="mt-2 h-32 w-full rounded-lg border border-white/10 overflow-hidden bg-black">
                                    <img src={newImage} alt="Preview" className="w-full h-full object-cover opacity-80" />
                                </div>
                            )}
                          </div>

                          <div>
                              <label className="block text-[10px] font-bold uppercase text-zinc-500 mb-1.5">Public Description</label>
                              <textarea required className="w-full bg-black border border-white/10 rounded-lg p-3 text-sm text-white resize-none focus:border-primary outline-none" rows={2} placeholder="Short teaser..." value={newDesc} onChange={e => setNewDesc(e.target.value)} />
                          </div>
                          
                          <div>
                              <label className="block text-[10px] font-bold uppercase text-primary mb-1.5 flex items-center gap-2">
                                    <span className="w-1.5 h-1.5 rounded-full bg-primary animate-pulse"/>
                                    Locked Content
                              </label>
                              <textarea required className="w-full bg-primary/5 border border-primary/20 rounded-lg p-3 font-mono text-xs text-zinc-200 resize-none focus:border-primary outline-none" rows={4} placeholder="The actual prompt text..." value={newPromptText} onChange={e => setNewPromptText(e.target.value)} />
                          </div>
                      </form>
                  </div>
                  
                  <div className="p-4 border-t border-white/5 flex gap-3 bg-black/20">
                      <Button type="button" variant="ghost" className="flex-1" onClick={() => setIsCreating(false)}>Cancel</Button>
                      <Button form="create-form" type="submit" variant="primary" className="flex-1" isLoading={loadingAction === 'create'}>Create</Button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
